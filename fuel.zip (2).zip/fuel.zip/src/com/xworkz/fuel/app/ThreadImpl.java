package com.xworkz.fuel.app;

public class ThreadImpl  extends Thread{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("running");
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("invoked satrt");
	}
	
	

}
